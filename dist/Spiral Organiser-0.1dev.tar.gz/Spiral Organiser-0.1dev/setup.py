from distutils.core import setup

setup(
    name='Spiral Organiser',
    version='0.1dev',
    packages=['spiralOrg',],
    license='GNU GPL v3',
    long_description=open('README.md').read(),
)
